declare module 'react-native/Libraries/Utilities/binaryToBase64' {
  export default function binaryToBase64(data: ArrayBuffer | Uint8Array): string;
}
