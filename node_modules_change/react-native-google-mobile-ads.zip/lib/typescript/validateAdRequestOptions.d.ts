import { RequestOptions } from './types/RequestOptions';
export declare function validateAdRequestOptions(options?: RequestOptions): RequestOptions;
//# sourceMappingURL=validateAdRequestOptions.d.ts.map