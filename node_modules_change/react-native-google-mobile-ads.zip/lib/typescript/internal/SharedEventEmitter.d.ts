import { EventEmitter } from 'react-native';
export declare const SharedEventEmitter: EventEmitter;
//# sourceMappingURL=SharedEventEmitter.d.ts.map