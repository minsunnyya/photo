export declare const version = "12.10.0";
//# sourceMappingURL=version.d.ts.map