import { RequestConfiguration } from './types/RequestConfiguration';
export declare function validateAdRequestConfiguration(requestConfiguration: RequestConfiguration): RequestConfiguration;
//# sourceMappingURL=validateAdRequestConfiguration.d.ts.map