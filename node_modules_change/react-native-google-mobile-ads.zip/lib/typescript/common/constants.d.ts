export declare enum RevenuePrecisions {
    ESTIMATED,
    PRECISE,
    PUBLISHER_PROVIDED,
    UNKNOWN
}
//# sourceMappingURL=constants.d.ts.map