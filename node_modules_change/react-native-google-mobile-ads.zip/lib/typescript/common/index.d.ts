export * from './validate';
export declare function hasOwnProperty(target: unknown, property: PropertyKey): boolean;
export declare function isPropertySet(target: unknown, property: PropertyKey): boolean;
//# sourceMappingURL=index.d.ts.map