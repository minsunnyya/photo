import React from 'react';
import { GAMBannerAdProps } from '../types/BannerAdProps';
export declare const BaseAd: React.ForwardRefExoticComponent<GAMBannerAdProps & React.RefAttributes<React.Component<import("./GoogleMobileAdsBannerViewNativeComponent").NativeProps, {}, any> & Readonly<import("react-native").NativeMethods>>>;
//# sourceMappingURL=BaseAd.d.ts.map