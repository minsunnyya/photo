import React from 'react';
import { GAMBannerAdProps } from '../types/BannerAdProps';
export declare class GAMBannerAd extends React.Component<GAMBannerAdProps> {
    private ref;
    recordManualImpression(): void;
    render(): JSX.Element;
}
//# sourceMappingURL=GAMBannerAd.d.ts.map