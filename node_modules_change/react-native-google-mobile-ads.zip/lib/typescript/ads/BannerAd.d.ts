/// <reference types="react" />
import { BannerAdProps } from '../types/BannerAdProps';
export declare function BannerAd({ size, ...props }: BannerAdProps): JSX.Element;
//# sourceMappingURL=BannerAd.d.ts.map