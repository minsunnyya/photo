import { AdsConsentInterface } from './types/AdsConsent.interface';
export declare const AdsConsent: AdsConsentInterface;
//# sourceMappingURL=AdsConsent.d.ts.map