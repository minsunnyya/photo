import { AdShowOptions } from './types/AdShowOptions';
export declare function validateAdShowOptions(options?: AdShowOptions): AdShowOptions;
//# sourceMappingURL=validateAdShowOptions.d.ts.map