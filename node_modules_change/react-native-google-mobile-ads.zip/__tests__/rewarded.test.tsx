describe('Admob Rewarded', () => {
  // eslint-disable-next-line jest/no-disabled-tests
  test.skip('skip', () => {});
});
