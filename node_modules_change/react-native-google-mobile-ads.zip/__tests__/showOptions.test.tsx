describe('Admob Show Options', () => {
  // eslint-disable-next-line jest/no-disabled-tests
  test.skip('skip', () => {});
});
