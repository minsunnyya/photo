describe('Admob RequestOptions', () => {
  // eslint-disable-next-line jest/no-disabled-tests
  test.skip('skip', () => {});
});
